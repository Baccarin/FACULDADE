from datetime import datetime

arquivo = open('respostas.txt', 'r')
conteudo = arquivo.readlines()

# insira seu conteúdo
# obs: o método append() é proveniente de uma lista
conteudo.append(str(datetime.now()))

# Abre novamente o arquivo (escrita)
# e escreva o conteúdo criado anteriormente nele.
arquivo = open('respostas.txt', 'w')
arquivo.writelines(conteudo)
print(conteudo)
arquivo.close()

