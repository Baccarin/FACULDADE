import paho.mqtt.client as mqtt
import json

def on_connect(client, userdata, flags, rc):
    print("Connected!")
    client.subscribe("sub/u0h64lrpc4gd/temperatura")

def on_message(client, data, msg):
    print(msg.topic + " " + str(msg.payload))


client = mqtt.Client()
client.on_message = on_message
client.on_connect = on_connect
client.username_pw_set("u0h64lrpc4gd", "uilpamsYxI2B")
client.connect("mqtt.demo.konkerlabs.net", 1883)
client.loop_forever()




