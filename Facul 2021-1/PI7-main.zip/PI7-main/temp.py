
import time
import subprocess

def mede_temp_processador():    
    cur_tempcpu = "cat /sys/class/thermal/thermal_zone0/temp"
    tempcpu = subprocess.check_output(cur_tempcpu, shell=True)
    cputempCelsius = str(float(tempcpu)/1000)
    print ("[DEBUG] Temperatura do processador: "+cputempCelsius+"C")
    return float(tempcpu)

print(mede_temp_processador)