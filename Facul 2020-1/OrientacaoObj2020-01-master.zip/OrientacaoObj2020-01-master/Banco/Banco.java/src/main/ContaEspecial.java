package main;

/*public class ContaEspecial extends ContaCorrente{

    protected Double limiteEmprestimo;


    public ContaEspecial(Double saldo,Integer numero, Pessoa titular,Double limiteEmprestimo){
        super(saldo, numero, titular);
        this.limiteEmprestimo = limiteEmprestimo;
    }

    public Double getLimiteEmprestimo() {
		return this.limiteEmprestimo;
	}

	public void setLimiteEmprestimo(Double limiteEmprestimo) {
		this.limiteEmprestimo = limiteEmprestimo;
    }
    
    public boolean validaEmprestimo(Double valor){
        if (valor > limiteEmprestimo){
            return false;
        }
        return true;
    }

    public void emprestimo(Double valor){
        if (validaEmprestimo(valor)){
            saldo += valor;
        }
    }
}*/