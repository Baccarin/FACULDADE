import hashlib
from threading import Thread
import mysql.connector
from mysql.connector import Error
from datetime import datetime


primeira =  ['A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

segunda =  ['!','@',',#','$','&','*','(',')','_','-','+','=','[',']','{','}','?','/','>','<',
	'0','1','2','3','4','5','6','7','8','9',
'A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

terceira = ['!','@',',#','$','&','*','(',')','_','-','+','=','[',']','{','}','?','/','>','<',
	'0','1','2','3','4','5','6','7','8','9',
'A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

quarta = ['!','@',',#','$','&','*','(',')','_','-','+','=','[',']','{','}','?','/','>','<',
	'0','1','2','3','4','5','6','7','8','9',
'A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

quinta =  ['!','@',',#','$','&','*','(',')','_','-','+','=','[',']','{','}','?','/','>','<',
	'0','1','2','3','4','5','6','7','8','9',
'A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

sexta =  ['!','@',',#','$','&','*','(',')','_','-','+','=','[',']','{','}','?','/','>','<',
	'0','1','2','3','4','5','6','7','8','9',
'A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

setima =  ['!','@',',#','$','&','*','(',')','_','-','+','=','[',']','{','}','?','/','>','<',
	'0','1','2','3','4','5','6','7','8','9',
'A','a','B','b','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','n','M','n','N','o','O','p','P',
'q','Q','r','R','S','t','T','u','U','v','V','w','W','X','x','Y','y','z','Z']

resposta1 = ["01a8649e264e14d4215065fb3eee2112","05968f80e5d2f335bddb6faf9cbe23ee",
"22aadb26447d87b550b155a4d764fad0","469ab2c03a994442b6d2f81a34fa3091"]

res1A = ["4b68e2cae855ed125433be90c76f6d8a","4fb164677becad4b371ddbba89b28a47",
"533e216ce150f00dae071be9449d29e5","56b0fbc82e5050909a1fbd10de711dbd"]

respos1B = ["22d5f5321072a715ae3d76907dda5c2f","27805b6edb985a5cb9e4912f21775a9b",
"31a468920cff1aad10753b5f14042824","3f5469ea889c05ea7e22153216c769d3"]

resp1C = ["b750c583c4740415f8c803198ad9a318",
"ecebb6d849809cf79fa2ba47c3730728","611ba5ef155b93d1cc990c1e3dfebe03","174d689df4b13b90121c3aaea1d015c4"]

resposta2 = ["b7bc2a2f5bb6d521e64c8974c143e9a0","05da33eab200f4c5b5ba3ed05beb2ec5","3164552fada5eede958a988bbb215163",
"64254db8396e404d9223914a0bd355d2","21ef05aed5af92469a50b35623d52101","df4e169df0449eb32075ada85240d69b"
"675ff4d1cf0c143f6f8a83b5bf19af81","adab360867b6bf1e2b57c050a2bc955f"]

resposta3 = ["572c2978f71bf4858e649f776a5d7dd8",
"5fa1b99a271b967b04b2952868081287","5fbcadef4caf526b04715e71ec38ceb2","67c1ffe07ead9acada98bb57c94989c4",
"67f1ae07542da043233c3aa5005c35b0","6913fd55dde3a1420304249c84486cc7","6ad3c6324400fd2d7304ac79ca87047f",
"6feb889691ef26940044c9bfd7e09c8f","72772597be404696f2278b02be6f04fb","735de7be155b9d078c9643042d1987ea"]

resposta4 = ["946c19824355d7501de9f0de408297d1",
"96cb4a09998411f8272f857d893265b0","99dd7946d77fd370bebb357c54eff46a","9cbe2e02d88bcd507f44f553bbef4cc6",
"9f0876be336b34cfda57d392292f05b6",'9f184130760a8991273d61aa23897dcc']

resposta5 = ["ce017e68f36932bae1faedc8b4a2d4c2",
"d0cbddd770c023ee20170c7dc1741d42","d29892b607f61993ab489cc2b4bc18a1","d45623e9bcf7ef0fc18f25dd1a8a3a3a",
"e54a8426475731f2561981e60630dbbe","eb81adcc4edfeccb1ba0f16dfe1a737f"]

resposta6 = ["462fa40d604d2c9b642208f78c3ca84e",
"462fa40d604d2c9b642208f78c3ca84e","6d76c1cb0ed1cbc1df98578e7b641743","e7a1897007ef65e67048383c6383d42c"
"63effa2530d088a06f071bc5f016f8d4"]

resp13 = ["29c3eea3f305d6b823f562ac4be35217"
"d4b35a0de71992ce8a5ba92571c6e679","fcea920f7412b5da7be0cf42b8c93759","124bd1296bec0d9d93c7b52a71ad8d5b" ]

resp14 = ["6e67d70788fcb5b5befdf09a7ca39e64","cfc6678c720739386ff2506ac18debae"
"4b70401e0604cc96e16d132408198e44","db802e9da4df58a5c33c7ff033ccfd5a"]

resposta7 = ["783a6eb17104d0f5175904e481ae7d74","7c52ef1d9350c608eb7eeced81bea0c4",
"7de0049ee50d1ed44a2f5a211be2a3b1","8421378d307e579d2681ef3b04e2aa1b","91321441ac234aad3549b3c815ffb8ad",
"827ccb0eea8a706c4c34a16891f84e7b","c4ded2b85cc5be82fa1d2464eba9a7d3"]

resposta8 = ["ecbd259dd576d0dc3f504c99a05d4303",
"eea7530d166b6279d2720929639973d1","f209b4ecb8fdfc2285e4175ea0ce489a","f37ff44fa840288762f16074a48ca191",
"f40eea175007de3bb7dd7436ef78a4a8","f947e6c5ca751155df70628f65c28967","9174e5b543aa4e8fdc07cc9dae7b5c80"
"34d9e14c87df4374163ba48265cd6729","f379eaf3c831b04de153469d1bec345e"]

resposta9 = ["a5043c328e52783c75dc1f12db4e3b93",
"ae2f866194753ab18a3a38b426b41958","b1507d468121e69e408c60cc0bc97c42","b8e12936fe4d5d19c37b9442e34c3839",
"c18d8827c555043b4db2a8c72de637ab","c295e2d817b939ed7cd97fede0a233ab","c8f5e09a214f83a610da0f17f1635797",
"ccd8fc809c2637abaa24f6161aad4a66","cdfce282f10b20571b7e542c0ab548ed"]


def loop1():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta1:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta1[resposta1.index(h)]): 
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append( '--HASH--  ')
								conteudo.append(str(datetime.now()))								
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()	
		print(palavra + " thread 1")

def loop2():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta2:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta2[resposta2.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()												
		print(palavra + " thread 2")	

def loop3():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta3:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta3[resposta3.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 3")

def loop4():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta4:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta4[resposta4.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 4")	

def loop5():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta5:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta5[resposta5.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 5")

def loop6():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta6:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta6[resposta6.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 6")				

def loop7():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta7:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta7[resposta7.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 7")				

def loop8():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta8:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta8[resposta8.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 8")				

def loop9():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resposta9:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resposta9[resposta9.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 9")				

def loop10():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in res1A:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == res1A[res1A.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 10")	

def loop11():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resp1C:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resp1C[resp1C.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append('/ --HASH--  /')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 11")			

def loop12():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in respos1B:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == respos1B[respos1B.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 12")	

def loop13():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resp13:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resp13[resp13.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append(' --HASH--  ')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 13")	

def loop14():
	for n1 in primeira: 
		for n2 in segunda: 
			for n3 in terceira:	 
				for n4 in quarta: 
					for n5 in quinta: 
						palavra = n1 + n2 + n3 + n4 + n5
						for h in resp14:
							code = hashlib.md5(palavra.encode())
							if (code.hexdigest() == resp14[resp14.index(h)]):  
								arquivo = open('respostas.txt', 'r')
								conteudo = arquivo.readlines()
								conteudo.append(palavra)
								conteudo.append('/ --HASH--  /')	
								conteudo.append(str(datetime.now()))							
								conteudo.append(code.hexdigest())								
								arquivo = open('respostas.txt', 'w')
								arquivo.writelines(conteudo)
								print(conteudo)
								arquivo.close()				
		print(palavra + " thread 14")	


def lancaThread():

	t1 = Thread(target=loop1, args=())
	t1.start()

	print(" thread 1 iniciada ")

	t2 = Thread(target=loop2, args=())
	t2.start()

	print(" thread 2 iniciada ")

	t3 = Thread(target=loop3, args=())
	t3.start()

	print(" thread 3 iniciada ")

	t4 = Thread(target=loop4, args=())
	t4.start()

	print(" thread 4 iniciada ")

	t5 = Thread(target=loop5, args=())
	t5.start()

	print(" thread 5 iniciada ")

	t6 = Thread(target=loop6, args=())
	t6.start()

	print(" thread 6 iniciada ")

	t7 = Thread(target=loop7, args=())
	t7.start()

	print(" thread 7 iniciada ")

	t8 = Thread(target=loop8, args=())
	t8.start()

	print(" thread 8 iniciada ")

	t9 = Thread(target=loop9, args=())
	t9.start()

	print(" thread 9 iniciada ")

	t10 = Thread(target=loop10, args=())
	t10.start()

	print(" thread 10 iniciada ")

	t11 = Thread(target=loop11, args=())
	t11.start()

	print(" thread 11 iniciada ")

	t12 = Thread(target=loop12, args=())
	t12.start()

	print(" thread 12 iniciada ")

	t13 = Thread(target=loop13, args=())
	t13.start()

	print(" thread 13 iniciada ")

	t14 = Thread(target=loop14, args=())
	t14.start()

	print(" thread 14 iniciada ")


lancaThread()