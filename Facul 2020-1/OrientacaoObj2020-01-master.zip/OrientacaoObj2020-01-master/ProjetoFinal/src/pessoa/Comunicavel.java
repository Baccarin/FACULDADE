package pessoa;

public interface Comunicavel {
    
   public boolean comunicavel();

}