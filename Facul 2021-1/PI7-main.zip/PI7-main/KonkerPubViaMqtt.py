#https://www.filipeflop.com/blog/plataforma-konker-iot-utilizando-a-plataforma-com-uma-raspberry-pi-zero-w/

import paho.mqtt.client as mqtt
import json
import time
import random
 
#usuario e senha do dispositivo na plataforma Konkerlabs
usuario_konkerlabs = "u0h64lrpc4gd"
senha_konkerlabs = "uilpamsYxI2B"
topico_publish = "pub/"+ 'u0h64lrpc4gd' +"/temperatura"
 
client = mqtt.Client()
client.username_pw_set(usuario_konkerlabs, senha_konkerlabs)
client.connect("mqtt.demo.konkerlabs.net", 1883)
 
while True:

    a = random.randint(0, 1000)
    #envia o valor aleatório entre 0 e 1000 para o konker
    payload_json = json.dumps({"temperature": a, "unit": "celsius"})
    client.publish(topico_publish, payload_json)
    print(a)
    time.sleep(5)